import React from 'react'
import reactLogo from './../logo.svg'

export default function ReactLogoAnimation() {
  return (
    <div className="react_logo_animation">
      <img src={reactLogo} alt="" />
    </div>
  )
}
